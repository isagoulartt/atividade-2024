export default function sobre(){
    return (
        <section  className="sobre">
            <h3>sobre</h3>
 <p>seja bem-vindo a minha página de gatitos! aqui vamos ver gatinhos fofinhos</p>
        </section>
    )
}