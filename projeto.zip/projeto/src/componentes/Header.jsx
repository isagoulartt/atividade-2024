function Header(){
    return (
        <header>
        <h1> Pagina de gatinhos </h1>
        </header>
    )
}

export default Header