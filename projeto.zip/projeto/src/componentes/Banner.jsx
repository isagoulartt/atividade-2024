export default function Banner(){
    return(
        <section className="Banner">
             <img src = "gatinhos.jpg"></img>
            
        </section>
    )
}