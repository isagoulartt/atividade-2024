
import './App.css'
import Header from './componentes/Header'

function App() {
 

  return (
    <div>
 <Header />
  <section>
    <img src = "gatinhos.jpg"></img>
  </section>
  <section>
    <h2> sobre </h2>
    <p>seja bem-vindo a minha página de gatitos! aqui vamos ver gatinhos fofinhos</p>
  </section>
  </div>
  )
}

export default App
