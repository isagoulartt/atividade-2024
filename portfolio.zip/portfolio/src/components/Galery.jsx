import React from 'react';
import ItemImg from './ItemImg';
import TextBig from './TextBig';
import Button from './Button';


export default function Galery(){
    return(
        <div className="one-column content">
            <TextBig label="Áreas do conhecimento" />
            <div className="inner-container">
                <ItemImg src="Title Page (2).png"label="Bob"/>
                <ItemImg src="Title Page (4).png" label="Mia"/>
                <ItemImg src= "Title Page (3).png" label="Tobi"/>
                <ItemImg src="Title Page (5).png" label="Zoe"/>
                <ItemImg src="Title Page (6).png" label="Roberta"/>
               
            
            </div>
            
        </div>
    )
}