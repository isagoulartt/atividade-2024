import React from 'react';


export default function Navbar(){
    return(
        <nav className="navbar">
          <li><a href="../App.jsx">Sobre mim </a></li>
          <li><a href=""> Currículo</a></li>
         
        </nav>
    )
}