import React from "react";
import TextBig from "./TextBig";

export default function About(){
    return(
        <div className="one-column content">
            <TextBig label="" />
        
        </div>
    )
}