import React from 'react';
import TextBig from './TextBig';
import Button from './Button';


export default function Banner(){
    return(
        <div className='banner container'>
            <div className="two-column content">
    
                <img src="WhatsApp Image 2024-04-11 at 10.51.12.jpeg" alt="bely" srcset="" />
            </div>
            <div className="two-column content">
                    <TextBig label="Bem-vindo ao meu portfólio 2024"/>
            </div>
            
        </div>
    )
}