export default function Banner(){
    return(
        <section className="Banner">
             <img id = "gato2" src= "gato 1.jpg"></img>
             <img id = "maromba" src = "maromba.jpg"></img>
             <img id = "fofo" src = "laranja.jpeg"></img>
             <img id = "nojo" src = "nojo.jpg"></img>

            
        </section>
    )
}