
import './App.css'
import Header from './componentes/Header'
import Banner from './componentes/Banner'
import Sobre from './componentes/Sobre'

function App() {
 

  return (
    <div>
      <Header/>
      <Banner/>
      <Sobre/>
  </div>
  )
}

export default App


